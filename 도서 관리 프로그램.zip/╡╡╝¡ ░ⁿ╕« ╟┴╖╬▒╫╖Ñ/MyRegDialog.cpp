﻿// MyRegDialog.cpp: 구현 파일
//

#include "pch.h"
#include "도서 관리 프로그램.h"
#include "afxdialogex.h"
#include "MyRegDialog.h"
#include "BookManager.h"

// MyRegDialog 대화 상자

IMPLEMENT_DYNAMIC(MyRegDialog, CDialogEx)

MyRegDialog::MyRegDialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_REG, pParent)	
	, title(_T(""))
	, content(_T(""))
	, bno(0)
	, date1(COleDateTime::GetCurrentTime())
	, date2(COleDateTime::GetCurrentTime())
{
	eeh = 0;
}

MyRegDialog::~MyRegDialog()
{
}

void MyRegDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DATETIMEPICKER1, dtp);
	DDX_Control(pDX, IDC_MONTHCALENDAR1, mc);
	DDX_Text(pDX, IDC_EDIT_TITLE, title);
	DDX_Text(pDX, IDC_EDIT_CONTENT, content);
	DDX_Text(pDX, IDC_STATIC_BNO, bno);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER1, date1);
	DDX_MonthCalCtrl(pDX, IDC_MONTHCALENDAR1, date2);
	DDX_Control(pDX, IDC_STATIC_IMG, pic_con);
	DDX_Control(pDX, IDC_EDIT_CONTENT, edit_cont);
}


BEGIN_MESSAGE_MAP(MyRegDialog, CDialogEx)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIMEPICKER1, &MyRegDialog::OnDtnDatetimechangeDatetimepicker1)
	ON_NOTIFY(MCN_SELCHANGE, IDC_MONTHCALENDAR1, &MyRegDialog::OnMcnSelchangeMonthcalendar1)
	ON_BN_CLICKED(IDC_BUTTON_IMG, &MyRegDialog::OnBnClickedButtonImg)
	ON_BN_CLICKED(IDC_BUTTON_SUB, &MyRegDialog::OnBnClickedButtonSub)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &MyRegDialog::OnBnClickedButtonCancel)
END_MESSAGE_MAP()


// MyRegDialog 메시지 처리기
void MyRegDialog::AddEndedEventHandler(EndDialogEventHandler* eeh)
{
	this->eeh = eeh;
}

void MyRegDialog::OnCancel()
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if (eeh)
	{
		eeh->EndedDialog();//나 죽음을 통보한다.
	}
	CDialogEx::OnCancel();
}


void MyRegDialog::OnDtnDatetimechangeDatetimepicker1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
	UpdateData();
	mc.SetCurSel(date1);
}


void MyRegDialog::OnMcnSelchangeMonthcalendar1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMSELCHANGE pSelChange = reinterpret_cast<LPNMSELCHANGE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	*pResult = 0;
	UpdateData();
	dtp.SetTime(date2);
}


void MyRegDialog::OnBnClickedButtonImg()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CFileDialog* fod = new CFileDialog(TRUE, 0);
	INT_PTR re = fod->DoModal();
	if (re != IDOK)
	{
		return;
	}
	image = fod->GetPathName();
	SetImage();
}
void MyRegDialog::SetImage()
{
	CImage cimg;
	try
	{
		cimg.Load(image);
	}
	catch (...)
	{
		image = TEXT("noimage.bmp");
		cimg.Load(image);
	}

	CDC* cdc = pic_con.GetDC();
	RECT rt;
	pic_con.GetClientRect(&rt);
	cimg.StretchBlt(*cdc, 0, 0, rt.right, rt.bottom, SRCCOPY);
}

void MyRegDialog::OnBnClickedButtonSub()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	UpdateData();//컨트롤=>변수
	if (image == TEXT(""))
	{
		image = TEXT("noimage.bmp");
	}
	BookManager& bm = BookManager::GetBookManager();
	if (bm.AddBook(title, content, image, date1) == FALSE)
	{
		MessageBox(TEXT("추가 실패"));	
	}
	InitControls();
}
void MyRegDialog::InitControls()
{
	title = TEXT("");
	content = TEXT("");
	image = TEXT("noimage.bmp");
	SetImage();
	UpdateData(FALSE);//변수=>컨트롤
	BookManager& bm = BookManager::GetBookManager();
	int bno = bm.GetNextBookNo();
	SetDlgItemInt(IDC_STATIC_BNO, bno, FALSE);
}


BOOL MyRegDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.	
	InitControls();
	return TRUE;  // return TRUE unless you set the focus to a control
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}


BOOL MyRegDialog::PreTranslateMessage(MSG* pMsg)
{
	// TODO: 여기에 특수화된 코드를 추가 및/또는 기본 클래스를 호출합니다.
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
	{
		if (GetFocus() == GetDlgItem(IDC_EDIT_CONTENT))
		{
			int len = edit_cont.GetWindowTextLength();
			edit_cont.SetSel(len,len);
			edit_cont.ReplaceSel(TEXT("\r\n"));
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}


void MyRegDialog::OnBnClickedButtonCancel()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	InitControls();
}
