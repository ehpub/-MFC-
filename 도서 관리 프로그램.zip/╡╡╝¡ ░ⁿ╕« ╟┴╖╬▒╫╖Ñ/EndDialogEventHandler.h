#pragma once
class EndDialogEventHandler
{
public:
	virtual void EndedDialog() = 0;
};

