﻿#pragma once
#include "afxdialogex.h"


// MyRegDialog 대화 상자
#include "EndDialogEventHandler.h"
class MyRegDialog : public CDialogEx
{
	EndDialogEventHandler* eeh;
	DECLARE_DYNAMIC(MyRegDialog)

public:
	MyRegDialog(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~MyRegDialog();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_REG };
#endif
public:
	void AddEndedEventHandler(EndDialogEventHandler *eeh);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
	virtual void OnCancel();
private:
	int bno;	
	CString title;
	CString content;	
	CString image;
	CDateTimeCtrl dtp;
	CMonthCalCtrl mc;
	COleDateTime date1;
	COleDateTime date2;
	CStatic pic_con;
	CEdit edit_cont;
public:
	afx_msg void OnDtnDatetimechangeDatetimepicker1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMcnSelchangeMonthcalendar1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBnClickedButtonImg();
	afx_msg void OnBnClickedButtonSub();
	afx_msg void OnBnClickedButtonCancel();

public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
private:
	void InitControls();
	void SetImage();
};
